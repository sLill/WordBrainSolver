﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WordBrain
{
    public partial class WordBrain : Form
    {
        private int _minWordLength = 2;
        private int _maxWordLength = 8;
        private object _possibleWordsLock = new object();

        private Dictionary<string,string> OxfordDictionary { get; set; }

        private string[][] Board { get; set; }

        public WordBrain()
        {
            InitializeComponent();

            cbMinLength.SelectedIndex = 0;
            cbMaxLength.SelectedIndex = cbMaxLength.Items.Count - 1;
        }

        private void InitializeBoard()
        {
            string boardString = txtBoard.Text;
            string[] rows = boardString.Split(';');

            Board = new string[rows.Length][];

            string[] chars;
            for (int i = 0; i < rows.Length; i++)
            {
                chars = rows[i].Split(',');
                Board[i] = chars;
            }
        }

        private void InitializeDictionary()
        {
            string path = $"{Environment.CurrentDirectory}/dictionary.txt";
            string[] dictionaryLines;

            _minWordLength = Convert.ToInt32(cbMinLength.Text);
            _maxWordLength = Convert.ToInt32(cbMaxLength.Text);

            OxfordDictionary = new Dictionary<string, string>();
            dictionaryLines = File.ReadAllLines(path);

            foreach (string line in dictionaryLines)
            {
                if (line != string.Empty)
                {
                    string word = line.Split(' ')[0];

                    if (word.Length >= _minWordLength && !OxfordDictionary.ContainsKey(word.ToUpper()))
                        OxfordDictionary.Add(word.ToUpper(), string.Empty);
                }
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            InitializeDictionary();
            InitializeBoard();

            List<string> possibleWords = new List<string>();
            for (int i = 0; i < Board.Length; i++)
            {
                Parallel.For(0, Board[i].Length, j =>
                {
                    Dictionary<string, string> localDictionary = OxfordDictionary;
                    List<string> wordsToAdd = FindPossibleWords(new List<string>(), localDictionary, Board[i][j].ToUpper(), i, j);

                    lock (_possibleWordsLock)
                    {
                        possibleWords.AddRange(wordsToAdd);
                    }
                });
            }

            for (int i = 0; i < possibleWords.Count; i++)
            {
                txtResults.Text += $"{possibleWords[i]}{Environment.NewLine}";
            }
        }

        private List<string> FindPossibleWords(List<string> possibleWords, Dictionary<string, string> localDictionary, string currString, int currRow, int currCol, int prevRow = -1, int prevCol = -1)
        {
            if (localDictionary.Count != 0 && currString.Length <= _maxWordLength)
            {
                Dictionary<string, string> loopSpecificDictionary;
                string newString;
                string dictionaryEntrySubstring;

                int startRowMatrixIndex = -1;
                int startColMatrixIndex = -1;
                int endingRowMatrixIndex = -1;
                int endingColRowMatrixIndex = -1;

                bool matchesCurrentPosition;
                bool matchesPreviousPosition;

                CalculateMatriceIndexes(ref startRowMatrixIndex, ref startColMatrixIndex, ref endingRowMatrixIndex, ref endingColRowMatrixIndex, currRow, currCol);

                for (int i = startRowMatrixIndex; i <= endingRowMatrixIndex; i++)
                {
                    for (int j = startColMatrixIndex; j <= endingColRowMatrixIndex; j++)
                    {
                        matchesCurrentPosition = (i == currRow && j == currCol) ? true : false;
                        matchesPreviousPosition = (i == prevRow && j == prevCol) ? true : false;

                        loopSpecificDictionary = new Dictionary<string, string>(localDictionary);

                        if (!matchesCurrentPosition && !matchesPreviousPosition)
                        {
                            newString = currString + Board[i][j].ToUpper();
                            if (newString.Length >= _minWordLength)
                            {
                                foreach (KeyValuePair<string, string> entry in localDictionary)
                                {
                                    dictionaryEntrySubstring = entry.Key.Substring(0, newString.Length);

                                    if (newString == entry.Key)
                                    {
                                        if (!possibleWords.Contains(entry.Key))
                                        {
                                            possibleWords.Add(entry.Key);
                                        }

                                        loopSpecificDictionary.Remove(entry.Key);
                                    }
                                    else if (newString.Length > entry.Key.Length || dictionaryEntrySubstring != newString)
                                    {
                                        loopSpecificDictionary.Remove(entry.Key);
                                    }
                                }
                            }

                            possibleWords = FindPossibleWords(possibleWords, loopSpecificDictionary, newString, i, j, currRow, currCol);
                        }
                    }
                }
            }

            return possibleWords;
        }

        private void CalculateMatriceIndexes(ref int startRowMatrixIndex, ref int startColMatrixIndex, ref int endingRowMatrixIndex, ref int endingcolMatrixIndex, int currentRowIndex, int currentColIndex)
        {
            if (currentRowIndex == 0)
                startRowMatrixIndex = currentRowIndex;
            else
                startRowMatrixIndex = currentRowIndex - 1;

            if (currentColIndex == 0)
                startColMatrixIndex = currentColIndex;
            else
                startColMatrixIndex = currentColIndex - 1;

            if (currentRowIndex == Board[0].Length - 1)
                endingRowMatrixIndex = currentRowIndex;
            else
                endingRowMatrixIndex = currentRowIndex + 1;

            if (currentColIndex == Board.Length - 1)
                endingcolMatrixIndex = currentColIndex;
            else
                endingcolMatrixIndex = currentColIndex + 1;
        }
    }
}
