﻿namespace WordBrain
{
    partial class WordBrain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtBoard = new System.Windows.Forms.TextBox();
            this.txtResults = new System.Windows.Forms.TextBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.lblMinLength = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cbMinLength = new System.Windows.Forms.ComboBox();
            this.cbMaxLength = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // txtBoard
            // 
            this.txtBoard.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoard.Location = new System.Drawing.Point(28, 12);
            this.txtBoard.Multiline = true;
            this.txtBoard.Name = "txtBoard";
            this.txtBoard.Size = new System.Drawing.Size(181, 84);
            this.txtBoard.TabIndex = 0;
            this.txtBoard.Text = "C,A,R;B,R,E;G,Z,S";
            // 
            // txtResults
            // 
            this.txtResults.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtResults.Location = new System.Drawing.Point(28, 114);
            this.txtResults.Multiline = true;
            this.txtResults.Name = "txtResults";
            this.txtResults.ReadOnly = true;
            this.txtResults.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtResults.Size = new System.Drawing.Size(181, 378);
            this.txtResults.TabIndex = 1;
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(134, 503);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 23);
            this.btnSearch.TabIndex = 2;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // lblMinLength
            // 
            this.lblMinLength.AutoSize = true;
            this.lblMinLength.Location = new System.Drawing.Point(16, 506);
            this.lblMinLength.Name = "lblMinLength";
            this.lblMinLength.Size = new System.Drawing.Size(63, 13);
            this.lblMinLength.TabIndex = 3;
            this.lblMinLength.Text = "Min Length:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 533);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Max Length:";
            // 
            // cbMinLength
            // 
            this.cbMinLength.FormattingEnabled = true;
            this.cbMinLength.Items.AddRange(new object[] {
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8"});
            this.cbMinLength.Location = new System.Drawing.Point(79, 503);
            this.cbMinLength.Name = "cbMinLength";
            this.cbMinLength.Size = new System.Drawing.Size(49, 21);
            this.cbMinLength.TabIndex = 5;
            // 
            // cbMaxLength
            // 
            this.cbMaxLength.FormattingEnabled = true;
            this.cbMaxLength.Items.AddRange(new object[] {
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11"});
            this.cbMaxLength.Location = new System.Drawing.Point(79, 530);
            this.cbMaxLength.Name = "cbMaxLength";
            this.cbMaxLength.Size = new System.Drawing.Size(49, 21);
            this.cbMaxLength.TabIndex = 6;
            // 
            // WordBrain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(234, 565);
            this.Controls.Add(this.cbMaxLength);
            this.Controls.Add(this.cbMinLength);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblMinLength);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.txtResults);
            this.Controls.Add(this.txtBoard);
            this.Name = "WordBrain";
            this.Text = "WordBrain";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtBoard;
        private System.Windows.Forms.TextBox txtResults;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Label lblMinLength;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbMinLength;
        private System.Windows.Forms.ComboBox cbMaxLength;
    }
}

